============================================================
 DATA PROCESSING TERMINAL  ·  v2.0 "EXPANSION"
 A retro-computing roguelike card game (Balatro-inspired)
============================================================

HOW TO PLAY
------------------------------------------------------------
WINDOWS:
  Double-click  "Play DATA PROCESSING TERMINAL.bat"
  -> opens in its own app window (no browser toolbar).

macOS:
  Double-click  "Play DATA PROCESSING TERMINAL.command"
  -> opens in its own app window (Chrome/Edge/Brave), or
     your default browser as a fallback.
  First time only: if macOS blocks it, right-click the file
  -> Open -> Open. (Gatekeeper warning for unsigned scripts.)

ANY SYSTEM:
  Double-click  DATA_PROCESSING_TERMINAL.html
  -> opens in your default browser.

No installation, no internet, no external files. Everything
(graphics, sound, save data) runs locally. Progress, stats,
unlocks and achievements are saved automatically in the
browser's local storage.

------------------------------------------------------------
 GAMEPLAY
------------------------------------------------------------
You are a computer operator processing batches of data.
Build poker hands from your dealt cards to score points and
meet each batch's QUOTA before you run out of hands.

  - Select up to 5 cards, then PROCESS HAND to score.
  - DISCARD cards you don't want (limited per batch).
  - Score = (base chips + card values + bonuses) x multiplier.
  - Clear the quota to reach the SHOP.
  - Buy SYSTEM MODULES (passive upgrade "jokers"), HARDWARE
    (permanent), SOFTWARE (single-use) and DATA DISKS
    (instant-use consumables).
  - Quotas keep rising. Survive as long as you can.
  - Random system EVENTS can help or hurt between batches.

------------------------------------------------------------
 WHAT'S NEW IN v2.0
------------------------------------------------------------
  - Smoother, fairer difficulty curve so runs last longer and
    you actually get to use your build.
  - 42 SYSTEM MODULES (was 16), including scaling jokers,
    synergy jokers and three LEGENDARY cores.
  - 9 HARDWARE upgrades and 7 SOFTWARE tools.
  - DATA DISKS: 16 instant consumables --
      * ALGORITHM routines permanently LEVEL UP a hand type.
      * Card ENHANCEMENTS: Foil, Holo, Gold, Bonus, +Mult,
        Volatile and Glitch -- each with its own card art.
      * Disk Clone duplicates a card (unlocks the new hands!).
  - 3 new poker hands: Five of a Kind, Flush House, Flush Five.
  - 39 ACHIEVEMENTS with an in-game gallery (main menu).
  - 14 system events and 17 unlockable monitor colors.
  - Reworked card visuals with enhancement badges and glow.

------------------------------------------------------------
 CONTROLS
------------------------------------------------------------
  1-8 / click .... select cards
  SPACE / ENTER .. process hand
  D .............. discard
  R / S .......... sort by rank / suit
  ESC ............ pause menu
  F11 ............ fullscreen
  Arrow keys ..... navigate main menu

------------------------------------------------------------
 SETTINGS
------------------------------------------------------------
Full Graphics / Audio / Gameplay / Accessibility / Controls
menus. Customize the monitor color, CRT scanlines, flicker,
curvature, brightness/contrast, sound volumes, animation
speed, accessibility options and more.

============================================================
