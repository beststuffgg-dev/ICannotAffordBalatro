#!/bin/bash
# DATA PROCESSING TERMINAL - macOS launcher
# Opens the game in its own app window (no browser toolbar). No install required.
DIR="$(cd "$(dirname "$0")" && pwd)"
GAME="file://$DIR/DATA_PROCESSING_TERMINAL.html"
for BROWSER in \
  "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome" \
  "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge" \
  "/Applications/Brave Browser.app/Contents/MacOS/Brave Browser" \
  "/Applications/Chromium.app/Contents/MacOS/Chromium"; do
  if [ -x "$BROWSER" ]; then
    "$BROWSER" --app="$GAME" --window-size=1180,820 >/dev/null 2>&1 &
    exit 0
  fi
done
# Fallback: default browser (normal tab)
open "$DIR/DATA_PROCESSING_TERMINAL.html"
