@echo off
REM ============================================================
REM  DATA PROCESSING TERMINAL - launcher
REM  Opens the game in app mode (no browser toolbar) so it
REM  behaves like a standalone window. No install required.
REM ============================================================
setlocal
set "GAME=%~dp0DATA_PROCESSING_TERMINAL.html"

set "EDGE=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
if exist "%EDGE%" (
  start "" "%EDGE%" --app="file:///%GAME:\=/%" --window-size=1180,820
  exit /b
)
set "EDGE=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
if exist "%EDGE%" (
  start "" "%EDGE%" --app="file:///%GAME:\=/%" --window-size=1180,820
  exit /b
)
set "CHROME=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
if exist "%CHROME%" (
  start "" "%CHROME%" --app="file:///%GAME:\=/%" --window-size=1180,820
  exit /b
)
set "CHROME=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
if exist "%CHROME%" (
  start "" "%CHROME%" --app="file:///%GAME:\=/%" --window-size=1180,820
  exit /b
)

REM Fallback: default browser
start "" "%GAME%"
exit /b
